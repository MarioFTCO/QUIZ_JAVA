/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package taller;

import java.util.ArrayList;

/**
 *
 * @author USER
 */
public class Catalogo {
private ArrayList<Vehiculo> vehiculos;

  public Catalogo() {
    vehiculos = new ArrayList<>(); 
  }

  public void agregarVehiculo(Vehiculo vehiculo) {
    vehiculos.add(vehiculo);
  }

  public Vehiculo venderVehiculo(String modelo) {
    for (Vehiculo v : vehiculos) {
      if (v.getModelo().equals(modelo)) {
        vehiculos.remove(v);
        return v;
      }
    }
    return null;
  }
  }

