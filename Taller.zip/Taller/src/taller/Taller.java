/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package taller;

import java.util.Scanner;

/**
 *
 * @author USER
 */
public class Taller {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Scanner teclado=new Scanner(System.in);
        System.out.println("Bienvenido al taller virtual");
        System.out.println("seleccione una categoria");

        Scanner scanner = new Scanner(System.in);
        int opcion =0;
        int opcion1=0;
        Catalogo tienda = new Catalogo();

        System.out.println("_________________________");
        System.out.println("Taller");
        System.out.println("=========================");
        System.out.println("1) Catalogo");
        System.out.println("2) Venta");
        System.out.println("3) Historial");
        System.out.println("4) Salir");
        System.out.println("=========================");  

        opcion = scanner.nextInt();
        switch (opcion){
            case 1:
                    
                System.out.println("Catologo");
                System.out.println("========================="); 
                System.out.println("1) agregar carros de transmision automatica");
                System.out.println("2) agregar carros de transmision manual");
                System.out.println("3) agregar motocicletas");
                System.out.println("4) atras");
                
                    switch (opcion1) {
                    case 1:
                        
                        tienda.agregarVehiculo(new Vehiculo("Ford",2000,2000,"automatico rojo")); 
                        
                        break;
                        
                    case 2:
                        
                        tienda.agregarVehiculo(new Vehiculo("Toyota",1200,1500,"manual blanco"));
                        
                        break;
                        
                    case 3:
                        
                        tienda.agregarVehiculo(new Vehiculo("Bsjaj Pulsar ns200",100,200,"negro"));
                        
                        break;
                        
                        
                    case 4:
                        
                        System.out.println("saliendo...");
                        
                        break;
                        
                    default:
                        throw new AssertionError();
                }
                
                break;
            
            case 2:
                
                System.out.println("Venta");
                System.out.println("========================="); 
                System.out.println("1) vender carros");
                System.out.println("3) vender motocicletas");
                System.out.println("4) atras");
                
                break;
            
            case 4:
                
                System.out.println("Saliendo..."); 
                
                break;
             
            default:
                
                System.out.println("Opción inválida");
                
        }
                
    }

}
